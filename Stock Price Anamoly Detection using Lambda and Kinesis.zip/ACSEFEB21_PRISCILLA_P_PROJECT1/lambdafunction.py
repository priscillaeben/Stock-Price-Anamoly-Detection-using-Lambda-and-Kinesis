import base64
import json
import boto3

print('Loading function')

client = boto3.client('sns', region_name='us-east-1')
topic_arn = "arn:aws:sns:us-east-1:756651670497:StockVariation"

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        print("Decoded payload: " + payload)
        #Now removing { and }
        s = payload.replace("{" ,"")
        finalstring = s.replace("}" , "")

        #Splitting the string based on , we get key value pairs
        list = finalstring.split(",")

        dictionary ={}
        for i in list:
            #Get Key Value pairs separately to store in dictionary
            keyvalue = i.split(":")

            #Replacing the single quotes in the leading.
            m= keyvalue[0].strip('\'')
            m = m.replace("\"", "")
            dictionary[m] = keyvalue[1].strip('"\'')

        priceDict = dictionary
        print("priceDict : " + str(priceDict))
        stockName = priceDict["'stockId"]
        priceCurrent = priceDict[" 'price"]
        price52weekHigh = priceDict[" '52WeekHigh"]
        price52weekLow = priceDict[" '52WeekLow"]
        HighVariance = float(price52weekHigh) * 0.8 
        LowVariance = float(price52weekLow) * 1.2
        print("Current price : " + str(priceCurrent))
        print("52 week high price : " + str(price52weekHigh))
        print("52 week low price : " + str(price52weekLow))

        if (float(priceCurrent) > HighVariance):
            message = "Current Price " + priceCurrent + " is nearing 52 week high price : " + price52weekHigh
            subject = "Stock Price 80% of 52 week high crossing alert for stock " + stockName
            client.publish(TopicArn=topic_arn, Message=message, Subject=subject)
            print("Price nearing 52 week High")
        else:
            print("Price didnt cross 80 percent of 52 week High")
   
        if (float(priceCurrent) < LowVariance):
            message = "Current Price " + priceCurrent + " is nearing 52 week low price : " + price52weekLow
            subject = "Stock Price 120% of 52 week low crossing alert for stock " + stockName
            client.publish(TopicArn=topic_arn, Message=message, Subject=subject)
            print("Price nearing 52 week Low")
        else:
            print("Price didnt cross 120 percent of 52 week Low")


    return 'Successfully processed {} records.'.format(len(event['Records']))
