import json
import boto3
import sys
import yfinance as yf
import re
import time
import random
import datetime


# Your goal is to get per-hour stock price data for a time range for the ten stocks specified in the doc. 
# Further, you should call the static info api for the stocks to get their current 52WeekHigh and 52WeekLow values.
# You should craft individual data records with information about the stockid, price, price timestamp, 52WeekHigh and 52WeekLow values and push them individually on the Kinesis stream

kinesis = boto3.client('kinesis', 
region_name = "us-east-1",
aws_access_key_id="ASIA3AK7UHPQ6UUGLGN4",
aws_secret_access_key="HXRJZ6R9BgEobeZSaH5nbpbNTNYg2BpZI06aLaZW",
aws_session_token="FwoGZXIvYXdzEHoaDFpLQycS0/0bErOSsiLHAWK4SIhMcSAkcuvBqKOqpApHimyP930b41Ao0Hms5I6LmDZGIW0o1NwrDRmoXiTtEFFHuZZcYBhiYFQLfnavuQUE55FCMaaer8dK3MRiuCL+uho/S9MT7vQAvdHDWyh8vnVpTfxhuWC+M09XzNm56sFnI9MlClcRaowYFxu1Npu+5P7Q1gX8RvOSgnz1yDWIIEBg0SHC9W8xBfLAcmWiIDUqe2EIm33w6z/TW04LrTRoARg2LpHZpjuukf62WRnsZxNkeEjB2FEoztmdigYyLT8Su7UNTfWL0S/NAWvsY2mrr48ikhb/eeRNlKT1BTmAae2IGOh/zGYz0kE36g=="
)

#Modify this line of code according to your requirement.

def kinesisStream(stockData):
    print('Input to Kinesis : ' +str(stockData))
    response = kinesis.put_record(
         StreamName="my-stock-kinesis-stream",
         Data=json.dumps(str(stockData)),
         PartitionKey="AdjustAsNeeded"
    )
    print(response)
    return;

today = datetime.date.today()
yesterday = datetime.date.today() - datetime.timedelta(1)
# stockDict is the global dictionary where we accumulate all the stock prices between two different dates
stockDict = {}
# Fetch the data between 2 dates from yfinance API
data = yf.download("MSFT", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
msft = yf.Ticker("MSFT")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'MSFT'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = msft.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = msft.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("MVIS", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("MVIS")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'MVIS'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("GOOG", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("GOOG")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'GOOG'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("SPOT", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("SPOT")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'SPOT'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("INO", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("INO")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'INO'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("OCGN", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("OCGN")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'OCGN'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("ABML", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("ABML")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'ABML'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("RLLCF", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("RLLCF")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'RLLCF'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("JNJ", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("JNJ")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'JNJ'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    

# Fetch the data between 2 dates from yfinance API
data = yf.download("PSFE", start="2021-09-17", end="2021-09-18",interval = '1h' )
# Ticker to take 52 week high and low prices
ticker = yf.Ticker("PSFE")
testDict = data.to_dict('split')
timestamps = []
prices = []
# Taking out stock timestamps
for times in testDict['index']:
    timestamps.append(str(times))
tot_entries = len(timestamps)
# Taking prices
for i in range(0,tot_entries):
    price = testDict['data'][i][3]
    prices.append(price)
tempDict = {}
# Constructing Data in Dict - stockId, price, priceTimestamp, 52 week High and 52 week Low
for j in range(0,tot_entries):
    tempDict['stockId'] = 'PSFE'
    tempDict['price'] = prices[j]
    tempDict['priceTimestamp'] = timestamps[j]
    tempDict['52WeekHigh'] = ticker.info['fiftyTwoWeekHigh']
    tempDict['52WeekLow'] = ticker.info['fiftyTwoWeekLow']
    kinesisStream(tempDict)
    tempDict = {}    